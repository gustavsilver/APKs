package com.example.aplicacionbdlogin;

import android.os.Parcel;
import android.os.Parcelable;

public class Usuario implements Parcelable {
    private int id;
    private String nombre;
    private String contraseña;
    private int id_tip;
    private String nom_tip;

    public Usuario() {
    }

    public Usuario(int id, String nombre, String contraseña, int id_tip, String nom_tip) {
        this.id = id;
        this.nombre = nombre;
        this.contraseña = contraseña;
        this.id_tip = id_tip;
        this.nom_tip = nom_tip;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getContraseña() {
        return contraseña;
    }

    public int getId_tip() {
        return id_tip;
    }

    public String getNom_tip() {
        return nom_tip;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setId_tip(int id_tip) {
        this.id_tip = id_tip;
    }

    public void setNom_tipo(String nom_tip) {
        this.nom_tip = nom_tip;
    }

    @Override
    public String toString() {
        return "" + id + "     " + nombre;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.id);
        dest.writeString(this.nombre);
        dest.writeString(this.contraseña);
        dest.writeInt(this.id_tip);
        dest.writeString(this.nom_tip);
    }

    protected Usuario(Parcel in) {
        this.id = in.readInt();
        this.nombre = in.readString();
        this.contraseña = in.readString();
        this.id_tip = in.readInt();
        this.nom_tip = in.readString();
    }

    public static final Parcelable.Creator<Usuario> CREATOR = new Parcelable.Creator<Usuario>() {
        @Override
        public Usuario createFromParcel(Parcel source) {
            return new Usuario(source);
        }

        @Override
        public Usuario[] newArray(int size) {
            return new Usuario[size];
        }
    };
}